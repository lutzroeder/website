// Lutz Roeder's .NET Reflector, SDK Example, January 2001.
// http://www.aisto.com/roeder/dotnet
// roeder@aisto.com
//

// Description:
// Show's how to add a new command to the tools menu of Reflector.
// Add the following in your configuration file:
//   <Commands>
//     <Command Type="Reflector.Command.MyDisassembler" CodeBase="Example2.dll"/>
//     ...
//   </Languages>

namespace Reflector.Commands
{
	using System;
	using System.Drawing;
	using System.Reflection;
	using System.Reflection.Emit;
	using System.Windows.Forms;

	using Reflector;
	using Reflector.Browser;
	using Reflector.ComponentModel;
	using Reflector.Disassembler;
	using Reflector.Library;
	using Reflector.UserInterface;

	internal sealed class MyDisassembler : ICommand
	{
		IApplication application = null;
		TextFlowPanel panel = null;

		public Image Image
		{
			get { return null; }
		}
  	
		public String Name  
		{ 
			get { return "My Disassembler (SDK)"; }
		}

		public String Description
		{
			get { return "My IL Diassembler (SDK example)"; }
		}

		public String Url
		{
			get { return "http://www.aisto.com/roeder/dotnet"; }
		}

		public String Copyright
		{
			get { return "Lutz Roeder"; }
		}

		public IApplication Application 
		{
			set { application = value; }
			get { return application; }
		}

		void ContextPanel_Navigate(Object s, MemberEventArgs e)
		{      
			if ((application == null) || (application.Browser == null)) return;
			application.Browser.GoToMember(e.Member);
		}

		public Boolean Enabled
		{
			get
			{
				if (application == null) return false;
				IBrowserNode node = application.Browser.Current;
				if (node == null) return false;
				if (node.Value == null) return false;
				return (node.Value is MethodBase);
			}
		}

		public void Execute()
		{
			if (panel == null)
			{
				panel = new TextFlowPanel(false);
				panel.Dock = DockStyle.Fill;
				panel.Navigate += new MemberEventHandler(ContextPanel_Navigate);
			}
    	
			Module module = GetCurrentModule();
			if (module == null) return;

			IBrowserNode node = application.Browser.Current;
			if (node.Value is MethodBase)
			{
				MethodBase methodBase = (MethodBase) node.Value;
      
				panel.Formatter = null;

				application.ToolForm.Text = "My Disassembler (SDK)";
				application.ToolForm.Open(panel);

				IFormatter f = new Formatter();
      
				try
				{
					ModuleReader reader = new ModuleReader(module, this.Application.AssemblyManager as IAssemblyLoader);
					MethodBody methodBody = reader.GetMethodBody(methodBase);

					if (methodBody != null)
						f.Write(Format(methodBody));
					else
						f.Write("Method can not be disassembled. Method body is either empty or contains native/optimized instructions.");

					f.Font = new Font("Courier New", 8.25f);
				}
				catch (ModuleReaderException exception)
				{
					f.WriteBold("Disassembler failed: ");
					f.Write(exception.Message);
					f.Properties.Write("Stack", exception.StackTrace);
				}
				catch (Exception exception)
				{
					f.WriteBold("Unhandled exception: ");
					f.Write(exception.Message);
					f.Properties.Write("Stack", exception.StackTrace);
				}

				panel.Formatter = (IHtmlFormatter) f;
			}
		}

		private Module GetCurrentModule()
		{
			IBrowserNode node = application.Browser.Current;

			if (node.Value is MethodBase)
			{
				MethodBase methodBase = (MethodBase) node.Value;
				return MemberHelper.GetModule(methodBase, application.AssemblyManager.Assemblies);
			}
    
			return null;
		}

		IFormatter Format(MethodBody methodBody)
		{
			IFormatter f = new Formatter();
			ILanguage language = application.LanguageManager.Current;
			if (language == null) return f;
    
			f.Properties.Write("Code Size", methodBody.CodeSize + " Bytes");	

			f.WriteBold(".maxstack " + methodBody.MaxStack);
			f.WriteLine();

			// Local variables
			Type[] locals = methodBody.Locals;
			if ((locals != null) && (locals.Length > 0))
			{
				f.WriteBold(".locals (");
				for (int i = 0; i < locals.Length; i++)
				{
					f.Write(language.Type(locals[i]));
					f.Write(" ");
					f.WriteBold("V_" + i);
					if (i != (locals.Length - 1)) f.Write(", ");
				}
				f.Write(")");
				f.WriteLine();
			}

			// Exception handlers
			ExceptionHandler[] exceptions = methodBody.Exceptions;
			if (exceptions != null)
			{
				foreach (ExceptionHandler handler in exceptions)
				{
					f.WriteBold(".try");
					f.Write(" ");
					f.Write("L_" + handler.TryOffset.ToString("x4"));
					f.Write(" ");
					f.WriteBold("to");
					f.Write(" ");
					f.Write("L_" + (handler.TryOffset + handler.TryLength).ToString("x4"));
					f.Write(" ");

					if (handler.Type == ExceptionHandlerType.Catch)
					{
						f.WriteBold("catch");
						f.Write(" ");
						f.Write(language.Type(handler.CatchType));
					}

					if (handler.Type == ExceptionHandlerType.Filter)
					{
						f.WriteBold("filter");
						f.Write(" ");
						f.Write("L_" + handler.FilterOffset.ToString("x4"));
					}

					if (handler.Type == ExceptionHandlerType.Finally) 
					{
						f.WriteBold("finally");
					}
					
					if (handler.Type == ExceptionHandlerType.Fault) 
					{
						f.WriteBold("fault");
					}

					f.Write(" ");
					f.Write("L_" + handler.HandlerOffset.ToString("x4"));
					f.Write(" ");
					f.WriteBold("to");
					f.Write(" ");
					f.Write("L_" + (handler.HandlerOffset + handler.HandlerLength).ToString("x4"));
					f.WriteLine();   
				}
			}

			// Instructions
			foreach (Instruction instruction in methodBody.Instructions)
			{
				OpCode opCode = instruction.OpCode;
				Object operand = instruction.Operand;
				Byte[] operandData = instruction.OperandData;

				f.Write("L_" + instruction.Offset.ToString("x4") + ": ");
				f.WriteBold(opCode.Name);
				f.Write(" ");

				if (operand != null)
				{
					switch (opCode.OperandType)
					{
						case OperandType.InlineNone:
							break;
  
						case OperandType.ShortInlineBrTarget:
						case OperandType.InlineBrTarget:
							int target = (int) operand;
							f.Write("L_" + target.ToString("x4"));
							break;

						case OperandType.ShortInlineI:
						case OperandType.InlineI:
						case OperandType.InlineI8:
						case OperandType.ShortInlineR:
						case OperandType.InlineR:
							f.Write(operand.ToString());
							break;

						case OperandType.InlineString:
							f.Write("\"" + operand.ToString() + "\"");
							break;

						case OperandType.ShortInlineVar:
						case OperandType.InlineVar:
							if (operand is int)
								f.Write("V_" + operand.ToString());
							else if (operand is ParameterInfo)
							{
								ParameterInfo parameterInfo = (ParameterInfo) operand;
								f.Write((parameterInfo.Name != null) ? parameterInfo.Name : ("A_" + parameterInfo.Position));
							}
							break;

						case OperandType.InlineSwitch:
							f.Write("(");
							int[] targets = (int[]) operand;
							for (int i = 0; i < targets.Length; i++)
							{
								if (i != 0) f.Write(", ");
								f.Write("L_" + targets[i].ToString("x4"));  
							}
							f.Write(")");
							break;

						case OperandType.InlineSig:
						case OperandType.InlineMethod:
						case OperandType.InlineField:
						case OperandType.InlineType:
						case OperandType.InlineTok:
							if (operand is Type)
							{
								Type type = (Type) operand;
								f.Write(language.Type(type));
							}
							else if (operand is MemberInfo)
							{
								MemberInfo memberInfo = (MemberInfo) operand;
								if (memberInfo.DeclaringType != null)
								{
									f.Write(language.Type(memberInfo.DeclaringType));
									f.Write("::");
								}
								f.WriteReference(memberInfo.Name, memberInfo.Name, memberInfo);
							}
							else
								throw new Exception();
							break;
					}
				}
				else
				{
					if (operandData != null)
					{
						f.Write("null");
						f.Write(" // " + instruction.OpCode.OperandType + " ");
						foreach (Byte b in operandData) f.Write(b.ToString("X2") + " ");
					}
				}      
   	  
				f.WriteLine();
			}
       	  
			return f; 
		}
	}

	class MemberHelper
	{
		public static Assembly GetAssembly(MemberInfo memberInfo, Assembly[] assemblies)
		{
			Module module = GetModule(memberInfo, assemblies);
			if (module == null) return null;
			return module.Assembly;	
		}

		public static Module GetModule(MemberInfo memberInfo, Assembly[] assemblies)
		{
			if (memberInfo is Type)
			{
				Type type = (Type) memberInfo;
				return type.Module;
			}	
    
			if (memberInfo.DeclaringType != null) 
				return memberInfo.DeclaringType.Module;
      
			foreach (Assembly assembly in assemblies)
				foreach (Module module in assembly.GetModules())
				{
					foreach (MethodInfo methodInfo in module.GetMethods())
						if (MemberHelper.Equals(methodInfo, memberInfo))
							return module;
					foreach (FieldInfo fieldInfo in module.GetFields())
						if (MemberHelper.Equals(fieldInfo, memberInfo))
							return module;
				}
      
			return null;
		}
	}

}
