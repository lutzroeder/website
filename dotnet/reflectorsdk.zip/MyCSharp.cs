// Lutz Roeder's .NET Reflector, SDK Example, January 2001.
// http://www.aisto.com/roeder/dotnet
// roeder@aisto.com
//

// Description:
// Shows how to add a new language view to Reflector.
// Add the following in your configuration file:
//   <Languages>
//     <Language Type="Reflector.Language.MyVisualBasic" CodeBase="Example1.dll"/>
//     ...
//   </Languages>

namespace Reflector.Languages
{
	using System;
	using System.Collections;
	using System.Drawing;
	using System.Reflection;
	using System.Text;
	
	using Reflector;
	using Reflector.ComponentModel;
	using Reflector.Library;
	
	class MyCSharp : ILanguage
	{
		LanguageHelper helper = new LanguageHelper();
	
		public IApplication Application
		{
			set { helper.Application = value; }
			get { return helper.Application; }	
		}
	
		public Image Image
		{
			get { return null; }
		}
	
		public String Name 
		{
			get { return "My C# (SDK)"; }
		}
	
		public String Description
		{
			get { return "My C# language view (SDK example)"; }
		}
	
		public String Url
		{
			get { return "http://www.aisto.com/roeder/dotnet"; }
		}
	
		public String Copyright
		{
			get { return "Lutz Roeder"; }
		}  
	
		public IFormatter AssemblyDeclaration(Assembly assembly)
		{
			return helper.AssemblyDeclaration(assembly);	
		}
	
		public IFormatter AssemblyReference(AssemblyName assemblyName)
		{
			return helper.AssemblyReference(assemblyName);
		}
	  
		public IFormatter ModuleDeclaration(Module module)
		{
			return helper.ModuleDeclaration(module);
		}
	
		public IFormatter ManifestResource(String resourceName, long resourceSize, ManifestResourceInfo manifestResourceInfo)
		{
			return helper.ManifestResource(resourceName, resourceSize, manifestResourceInfo); 
		}
	  
		public IFormatter Resource(String name, Object value)
		{
			return helper.Resource(name, value, this);
		}
	
		public IFormatter NamespaceDeclaration(String Namespace)
		{
			IFormatter f = new Formatter();
			f.Write("namespace ");
			f.WriteBold(Namespace);
			return f;
		}
	
		public IFormatter Type(Type type)
		{
			IFormatter f = new Formatter();
			if (type == null)
			{
				f.Write("?");
				return f;
			}
	
			if ((type.IsArray) && (type != typeof(Array)))
			{
				f.Write(Type(type.GetElementType()));
				f.Write("[");
				for (int i = type.GetArrayRank(); i > 1; i--) f.Write(",");
				f.Write("]");      
			}
			else if (type.IsByRef)
			{
				f.Write("ref ");
				f.Write(Type(type.GetElementType()));
			}
			else if (type.IsPointer)
			{
				f.Write(Type(type.GetElementType()));
				f.Write("*");
			}
			else
			{
				String name = type.Name;
				if (type == typeof(void)) name = "void";
				if (type == typeof(Object)) name = "object";
				if (type == typeof(String)) name = "string";
				if (type == typeof(SByte)) name = "sbyte";
				if (type == typeof(Byte)) name = "byte";
				if (type == typeof(Int16)) name = "short";
				if (type == typeof(UInt16)) name = "ushort";
				if (type == typeof(Int32)) name = "int";
				if (type == typeof(UInt32)) name = "uint";
				if (type == typeof(Int64)) name = "long";
				if (type == typeof(UInt64)) name = "ulong";
				if (type == typeof(Char)) name = "char";
				if (type == typeof(Boolean)) name = "bool";
				if (type == typeof(Single)) name = "float";
				if (type == typeof(Double)) name = "double";
				if (type == typeof(Decimal)) name = "decimal";
				f.WriteReference(name, type.FullName, type);
			}
	
			return f;	
		}
	
		public IFormatter TypeDeclaration(Type type)
		{
			IFormatter f = new Formatter();
			f.Write(helper.CustomAttributes(type, String.Empty, true));
			if ((type.IsPublic) || (type.IsNestedPublic))
				f.Write("public ");
			else if (!type.IsNestedPrivate) 
				f.Write("private ");
			else if (type.IsNestedAssembly)
				f.Write("internal ");
			if (type.IsNestedFamily)
				f.Write("protected ");
			else if (type.IsNestedFamANDAssem) 
				f.Write("protected internal "); 
			else if (type.IsNestedFamORAssem) 
				f.Write("internal protected ");
	
			if (TypeHelper.IsDelegate(type))
			{
				f.Write("delegate ");
				MethodInfo invoke = type.GetMethod("Invoke");
				f.Write(Type(invoke.ReturnType));
				f.Write(" ");
				f.WriteBold(type.Name);
				f.Write("(");
				f.Write(Parameters(invoke.GetParameters()));
				f.Write(")");
			}
			else
			{ 
				if (type.IsEnum) 
				{
					f.Write("enum ");
					f.WriteBold(type.Name);
				}
				else
				{
					Boolean colon = false;
					if (type.IsValueType)
					{
						f.Write("struct ");
						f.WriteBold(type.Name);
					}
					else if (type.IsInterface)
					{
						f.Write("interface "); 
						f.WriteBold(type.Name);
					}
					else
					{
						if (type.IsAbstract) f.Write("abstract ");
						if (type.IsSealed) f.Write("sealed ");
						f.Write("class ");
						f.WriteBold(type.Name);
	
						Type baseType = type.BaseType;
						if ((baseType != null) && (baseType != typeof(object)))
						{
							f.Write(" : ");
							f.Write(Type(baseType));
							colon = true;	
						}
					}
	
					Type[] types = TypeHelper.GetInterfaces(type);
					foreach (Type interfaceType in types)
					{
						f.Write(colon ? ", " : " : ");
						f.Write(Type(interfaceType));
						colon = true;	
					}
				}    
			}
	
			f.Properties.Write((type.DeclaringType != null) ? "Declaring Type" : "Namespace", TypeHelper.GetResolutionScope(type));
			f.Properties.Write("GUID", type.GUID.ToString());
			return f;
		}
	
		public IFormatter TypeReference(Type type)
		{
			IFormatter f = new Formatter();
	    
			if (TypeHelper.IsDelegate(type))
				f.Write("delegate ");
			else if (type.IsEnum)
				f.Write("enum ");
			else if (type.IsValueType)
				f.Write("struct ");
			else if (type.IsInterface)
				f.Write("interface ");
			else if (type.IsClass)
				f.Write("class ");
	
			f.Write(Type(type));
			f.Properties.Write((type.DeclaringType != null) ? "Declaring Type" : "Namespace", TypeHelper.GetResolutionScope(type));
			return f;
		}
	
		public IFormatter ConstructorDeclaration(ConstructorInfo constructorInfo)
		{
			IFormatter f = new Formatter();    	
			f.Write(helper.CustomAttributes(constructorInfo, String.Empty, true));
			f.Write(MethodBaseModifiers(constructorInfo));
			f.WriteBold(constructorInfo.DeclaringType.Name);
			f.Write("(");
			f.Write(Parameters(constructorInfo.GetParameters()));
			if (constructorInfo.CallingConvention == CallingConventions.VarArgs) f.Write(", __arglist");
			f.Write(");");
			return f;
		}
	
		public IFormatter MethodDeclaration(MethodInfo methodInfo)
		{
			IFormatter f = new Formatter();
			f.Write(helper.CustomAttributes(methodInfo.ReturnType, "return: ", true));
			f.Write(helper.CustomAttributes(methodInfo, String.Empty, true));
			f.Write(MethodBaseModifiers(methodInfo));    
	
			String name = methodInfo.Name;
			if (methodInfo.IsSpecialName)
			{
				if (name == "op_UnaryPlus") name = "+";
				if (name == "op_Addition") name = "+";
				if (name == "op_Increment") name = "++";
				if (name == "op_UnaryNegation") name = "-";
				if (name == "op_Subtraction") name = "-";
				if (name == "op_Decrement") name = "--";
				if (name == "op_Multiply") name = "*";
				if (name == "op_Division") name = "/";
				if (name == "op_Modulus") name = "%";
				if (name == "op_BitwiseAnd") name = "&";
				if (name == "op_BitwiseOr") name = "|";
				if (name == "op_ExclusiveOr") name = "^";
				if (name == "op_Negation") name = "!";
				if (name == "op_OnesComplement") name = "~";
				if (name == "op_LeftShift") name = "<<";
				if (name == "op_RightShift") name = ">>";
				if (name == "op_Equality") name = "==";
				if (name == "op_Inequality") name = "!=";
				if (name == "op_GreaterThanOrEqual") name = ">=";
				if (name == "op_LessThanOrEqual") name = "<=";
				if (name == "op_GreaterThan") name = ">";
				if (name == "op_LessThan") name = "<";
				if (name == "op_True") name = "true";
				if (name == "op_False") name = "false";
				if (name == "op_Implicit") name = "implicit";
				if (name == "op_Explicit") name = "explicit";
			}
	
			if (name != methodInfo.Name)
			{
				if ((name == "explicit") || (name == "implicit"))
				{
					f.WriteBold(name);
					f.WriteBold(" operator ");
					f.Write(Type(methodInfo.ReturnType));
				}
				else
				{
					f.Write(Type(methodInfo.ReturnType));
					f.WriteBold(" operator ");
					f.WriteBold(name);        
				}
			}
			else
			{
				f.Write(Type(methodInfo.ReturnType));
				f.Write(" ");
				f.WriteBold(name);
			}
	
			f.Write("(");
			f.Write(Parameters(methodInfo.GetParameters()));
			if (methodInfo.CallingConvention == CallingConventions.VarArgs) f.Write(", __arglist");
			f.Write(");");
			return f;
		}
	
		public IFormatter EventDeclaration(EventInfo eventInfo)
		{
			IFormatter f = new Formatter();
			f.Write(helper.CustomAttributes(eventInfo, String.Empty, true));
			f.Write("public ");
			f.Write("event");
			f.Write(" ");
			f.Write(Type(eventInfo.EventHandlerType));
			f.Write(" ");
			f.WriteBold(eventInfo.Name);
			f.Write(";");
			return f;
		}
	
		public IFormatter PropertyDeclaration(PropertyInfo propertyInfo)
		{
			IFormatter f = new Formatter();    	
	
			f.Write(helper.CustomAttributes(propertyInfo, String.Empty, true));
	    
			MethodInfo get = propertyInfo.GetGetMethod(true);
			MethodInfo set = propertyInfo.GetSetMethod(true);
			Boolean equal = ((set == get) || ((set == null) || (get == null) || (set.Attributes == get.Attributes)));
			if (equal) f.Write((get == null) ? MethodBaseModifiers(set) : MethodBaseModifiers(get));
	    
			f.Write(Type(propertyInfo.PropertyType));
			f.Write(" ");
			f.WriteBold(propertyInfo.Name.Equals("Item") ? "this" : propertyInfo.Name);
			ParameterInfo[] parameters = propertyInfo.GetIndexParameters();
			if (parameters.Length > 0)
			{
				f.Write("[");
				f.Write(Parameters(parameters)); 
				f.Write("]");
			}
	
			f.Write(" {");
	
			if (propertyInfo.CanRead)
			{
				f.Write(" ");
				if (!equal) f.Write(MethodBaseModifiers(get));
				f.WriteBold("get");
				f.Write(";");
			}
			if (propertyInfo.CanWrite)
			{
				f.Write(" ");
				if (!equal) f.Write(MethodBaseModifiers(set));
				f.WriteBold("set");
				f.Write(";");
			}
			f.Write(" }");
			return f;
		}
	
		public IFormatter FieldDeclaration(FieldInfo fieldInfo)
		{
			IFormatter f = new Formatter();
			f.Write(helper.CustomAttributes(fieldInfo, String.Empty, true));
			Boolean isEnum = (FieldHelper.IsEnumerationElement(fieldInfo));
	
			if (!isEnum)
			{
				if (fieldInfo.IsPublic) 
					f.Write("public ");
				else if (fieldInfo.IsPrivate)
					f.Write("private ");
				else if (fieldInfo.IsFamily)
					f.Write("protected ");
				else if (fieldInfo.IsAssembly)
					f.Write("internal ");
				else if (fieldInfo.IsFamilyAndAssembly)
					f.Write("protected internal ");
				else if (fieldInfo.IsFamilyOrAssembly)
					f.Write("internal protected ");
	
				if ((fieldInfo.IsLiteral) && (fieldInfo.IsStatic))
				{
					f.Write("const ");
				}
				else
				{
					if (fieldInfo.IsStatic) f.Write("static ");
					if (fieldInfo.IsInitOnly) f.Write("readonly ");
				}
	
				f.Write(Type(fieldInfo.FieldType));
				f.Write(" ");
			}
	
			f.WriteBold(fieldInfo.Name);
			f.Write(helper.FieldInitialValue(fieldInfo, " = "));
			f.Write(";");
			return f;
		}
	
		IFormatter ParameterDeclaration(ParameterInfo parameterInfo)
		{
			IFormatter f = new Formatter();
			f.Write(helper.ParameterDeclarationAttribtues(parameterInfo));
			f.Write(helper.CustomAttributes(parameterInfo, String.Empty, false));
			f.Write(Type(parameterInfo.ParameterType));
			if (parameterInfo.Name != null)
			{
				f.Write(" ");
				f.Write(parameterInfo.Name);
			}
			f.Write(helper.ParameterDefaultValue(parameterInfo));
			return f;
		}
	
		IFormatter Parameters(ParameterInfo[] parameters)
		{
			IFormatter f = new Formatter();
			for (int i = 0; i < parameters.Length; i++)
			{
				if (i != 0) f.Write(", ");
				Type type = parameters[i].ParameterType;
				if ((type.IsArray) && (type != typeof(Array)) && Attribute.IsDefined(parameters[i], typeof(ParamArrayAttribute), true)) f.Write("params ");
				f.Write(ParameterDeclaration(parameters[i]));
			}
			return f;
		}
	
		IFormatter MethodBaseModifiers(MethodBase methodBase)
		{
			IFormatter f = new Formatter();
			if (methodBase == null) return f;
	    
			if (methodBase.IsPublic) 
				f.Write("public ");
			else if (methodBase.IsPrivate)
				f.Write("private ");
			else if (methodBase.IsFamily)
				f.Write("protected ");
			else if (methodBase.IsAssembly)
				f.Write("internal ");
			else if (methodBase.IsFamilyAndAssembly)
				f.Write("protected internal ");
			else if (methodBase.IsFamilyOrAssembly)
				f.Write("internal protected ");
	
			if (methodBase.IsStatic) f.Write("static ");
			MethodAttributes attributes = methodBase.Attributes;
			if (((attributes & MethodAttributes.Final) != 0) && (((attributes & MethodAttributes.Virtual) != 0) & ((attributes & MethodAttributes.NewSlot) != 0))) attributes = 0;
			if ((attributes & MethodAttributes.Final) != 0) f.Write("sealed ");
			if (((attributes & MethodAttributes.Virtual) != 0) && (methodBase.DeclaringType != null) && (!methodBase.DeclaringType.IsInterface))
			{
				switch (attributes & (MethodAttributes.NewSlot | MethodAttributes.Abstract))
				{
					case 0:        	
						f.Write("override ");
						break;
					case MethodAttributes.NewSlot:
						f.Write("virtual ");
						break;
					case MethodAttributes.Abstract:
						f.Write("abstract override ");
						break;
					case MethodAttributes.NewSlot | MethodAttributes.Abstract:
						f.Write("abstract ");
						break;
				}
			}
	
			return f;
		}

		public IFormatter TypeView(Type[] types)
		{
			IFormatter f = new Formatter();
			f.Write("Not supported for My C#.");
			return f;
		}
	}
	
	class LanguageHelper
	{
		IApplication application = null;
	
		public IApplication Application
		{
			set { application = value; }	
			get { return application; }
		}
	
		public IFormatter AssemblyDeclaration(Assembly assembly)
		{
			IFormatter f = new Formatter();
			f.Write(CustomAttributes(assembly, "assembly: ", true));
			f.Write("Assembly");
			f.Write(" ");
			AssemblyName assemblyName = assembly.GetName(false);
			f.WriteBold(assemblyName.Name);
			f.Properties.Write("Version", assemblyName.Version.ToString());
			f.Properties.Write("Name", assembly.FullName);
			return f;
		}
	
		public IFormatter AssemblyReference(AssemblyName assemblyName)
		{
			IFormatter f = new Formatter();
			f.Write("Assembly-Reference ");
			f.WriteBold(assemblyName.Name);
			f.Properties.Write("Version", assemblyName.Version.ToString());
			f.Properties.Write("Name", assemblyName.FullName);
			return f;
		}
	  
		public IFormatter ModuleDeclaration(Module module)
		{
			IFormatter f = new Formatter();
			f.Write(CustomAttributes(module, "module: ", true));
			f.Write("Module");
			f.Write(" ");
			f.WriteBold(module.Name);
			f.Properties.Write("File", module.FullyQualifiedName);
			f.Properties.Write("Scope", module.ScopeName);
			return f;
		}
	
		public IFormatter ManifestResource(String resourceName, long resourceSize, ManifestResourceInfo manifestResourceInfo)
		{
			IFormatter f = new Formatter();
			f.Write("Manifest-Resource ");
			f.WriteBold(resourceName);
			f.Properties.Write("Size", resourceSize.ToString() + " Bytes");
			if ((manifestResourceInfo.FileName != null) && (manifestResourceInfo.FileName != String.Empty))
				f.Properties.Write("Filename", manifestResourceInfo.FileName);
			if (manifestResourceInfo.ReferencedAssembly != null)
				f.Properties.Write("Assembly", manifestResourceInfo.ReferencedAssembly.FullName);
			if (manifestResourceInfo.ResourceLocation != 0)
				f.Properties.Write("Location", manifestResourceInfo.ResourceLocation.ToString());
			return f;
		}
	
		public IFormatter Resource(String name, Object value, ILanguage language)
		{
			IFormatter f = new Formatter();
			f.Write("Resource ");
			f.WriteBold(name);
			f.Write(" : ");
			f.Write(language.Type(value.GetType()));
			if (value is String)
				f.Properties.Write("Value", "\"" + value.ToString() + "\"");
			return f;
		}
	
		public IFormatter FieldInitialValue(FieldInfo fieldInfo, String assignment)
		{
			IFormatter f = new Formatter();
			if (!fieldInfo.IsStatic || !fieldInfo.IsLiteral) return f;
							
			Object value = null;
	
			try
			{
				value = fieldInfo.GetValue(fieldInfo.DeclaringType);
				if ((fieldInfo.DeclaringType != null) && (fieldInfo.DeclaringType.IsEnum)) 
					value = Convert.ToInt32(fieldInfo.GetValue(null)); 
			}
			catch {}
	
			if (value != null)
			{
				String text = value.ToString();
				if (value is String) text = "\"" + text + "\"";
				if (value is Char) text = "\'" + text + "\'";
				if (text != String.Empty) f.Write(assignment + text);
			}
	
			return f;
		}
	
		public IFormatter ParameterDefaultValue(ParameterInfo parameterInfo)
		{
			IFormatter f = new Formatter();
			Object value = null;
			try { value = parameterInfo.DefaultValue; } 
			catch { }
			String text = value.ToString();
			if (value is String) text = "\"" + text + "\"";
			if (value is Char) text = "\'" + text + "\'";
			if (text != String.Empty) f.Write(" = " + text);
			return f;    
		}
	
		public IFormatter ParameterDeclarationAttribtues(ParameterInfo parameterInfo)
		{
			IFormatter f = new Formatter();
			ArrayList list = new ArrayList();
			if (parameterInfo.IsIn) list.Add("in");
			if (parameterInfo.IsOut) list.Add("out");
			if (parameterInfo.IsLcid) list.Add("lcid");
			if (parameterInfo.IsOptional) list.Add("optional");
			if (parameterInfo.IsRetval) list.Add("retval");
	
			StringBuilder builder = new StringBuilder();
			if (list.Count != 0)
			{
				builder.Append("[");
				for (int i = 0; i < list.Count; i++)
				{
					builder.Append((String) list[0]);
					if (i != (list.Count - 1)) builder.Append(",");
				}
				builder.Append("[");
			}
	
			return f;
		}
	
		public IFormatter TypeViewBody(Type type, ILanguage language)
		{
			IFormatter f = new Formatter();
			
			PropertyInfo[] properties = new PropertyInfo[0];
			try { properties = type.GetProperties(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Instance | BindingFlags.DeclaredOnly | BindingFlags.DeclaredOnly); } 
			catch {}
			EventInfo[] events = new EventInfo[0];
			try { events = type.GetEvents(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Instance | BindingFlags.DeclaredOnly); } 
			catch {}
	
			MemberInfo[] members = new MemberInfo[0];
	
			if (application.Settings.Sort)
			{
				ConstructorInfo[] constructors = new ConstructorInfo[0];
				try { constructors = type.GetConstructors(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Instance | BindingFlags.DeclaredOnly); } 
				catch { }
				MethodInfo[] methods = new MethodInfo[0];
				try { methods = type.GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Instance | BindingFlags.DeclaredOnly); } 
				catch { }
				FieldInfo[] fields = new FieldInfo[0];
				try { fields = type.GetFields(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Instance | BindingFlags.DeclaredOnly); } 
				catch { }
				IComparer comparer = new MemberComparer();
				Array.Sort(constructors, comparer);
				Array.Sort(methods, comparer);
				Array.Sort(events, comparer);
				Array.Sort(properties, comparer);
				Array.Sort(fields, comparer);
				ArrayList memberList = new ArrayList();
				memberList.AddRange(constructors);
				memberList.AddRange(methods);
				memberList.AddRange(events);
				memberList.AddRange(properties);
				memberList.AddRange(fields);
				members = (MemberInfo[]) memberList.ToArray(typeof(MemberInfo));
			}
			else
			{
				try { members = type.GetMembers(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Instance | BindingFlags.DeclaredOnly); } 
				catch { }
			}
			
			foreach (MemberInfo memberInfo in members)
			{
				if (memberInfo is ConstructorInfo)
				{
					ConstructorInfo constructorInfo = (ConstructorInfo) memberInfo;
					if (application.Visibility.Method(constructorInfo))
					{
						f.Write(language.ConstructorDeclaration(constructorInfo));
						f.WriteLine();      
					}
				}	
	
				if (memberInfo is MethodInfo)
				{
					MethodInfo methodInfo = (MethodInfo) memberInfo;
					if (application.Visibility.Method(methodInfo))
						if ((!application.Settings.Sort) || (!MethodHelper.IsPropertyMethod(methodInfo, null)) && !MethodHelper.IsEventMethod(methodInfo, null))
						{
							f.Write(language.MethodDeclaration(methodInfo));
							f.WriteLine();      
						}
				}	
	
				if (memberInfo is EventInfo)
				{
					EventInfo eventInfo = (EventInfo) memberInfo;
					if (application.Visibility.Event(eventInfo))
					{
						f.Write(language.EventDeclaration(eventInfo));
						f.WriteLine();      
					}
				}	
	
				if (memberInfo is PropertyInfo)
				{
					PropertyInfo propertyInfo = (PropertyInfo) memberInfo;
					if (application.Visibility.Property(propertyInfo))
					{
						f.Write(language.PropertyDeclaration(propertyInfo));
						f.WriteLine();      
					}
				}	
	
				if (memberInfo is FieldInfo)
				{
					FieldInfo fieldInfo = (FieldInfo) memberInfo;
					if (application.Visibility.Field(fieldInfo))
					{
						f.Write(language.FieldDeclaration(fieldInfo));
						f.WriteLine();      
					}
				}	
			}    
	
			return f;
		}
	
		IFormatter CustomAttribute(Object customAttribute)
		{
			Type type = customAttribute.GetType();
			String typeName = type.Name;
			if (typeName.EndsWith("Attribute"))
				typeName = typeName.Substring(0, typeName.Length - 9);
	
			PropertyInfo[] properties = type.GetProperties(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Instance | BindingFlags.DeclaredOnly);
			Boolean first = true;
			String values = String.Empty;
			foreach (PropertyInfo propertyInfo in properties)
			{
				if (!first) values += Environment.NewLine;
				first = false;
				Object value = propertyInfo.GetValue(customAttribute, null);
				values += propertyInfo.Name + " = ";
				if (value != null)
				{
					String quote = (value.GetType() == typeof(String)) ? "&quot;" : String.Empty;
					values += quote + value.ToString().Replace('\0', ' ') + quote;
				}
				else
					values += "null";
			}
	
			IFormatter f = new Formatter();
			f.WriteReference(typeName, values, type);
			return f;
		}
	
		public IFormatter CustomAttributes(ICustomAttributeProvider provider, String prefix, Boolean newLine)
		{
			IFormatter f = new Formatter();
			if (!Application.Settings.CustomAttributes) return f;    
			Object[] customAttributes = new Object[0];
			try { customAttributes = provider.GetCustomAttributes(true); } 
			catch { return f; }
			if (customAttributes.Length == 0) return f;
	
			f.Write("[");
			if (prefix != String.Empty) f.Write(prefix);
	
			foreach (Object customAttribute in customAttributes)
			{
				f.Write(CustomAttribute(customAttribute));
				if (customAttribute != customAttributes[customAttributes.Length - 1])
					f.Write(", ");
			}
	
			f.Write("]");
			f.WriteLine();
			return f;
		}
	}
	
	class TypeHelper
	{
		public static Boolean IsDelegate(Type type)
		{
			return ((type.IsSubclassOf(typeof(Delegate))) && (type != typeof(MulticastDelegate)));
		}
	
		public static Type[] GetInterfaces(Type type)
		{
			if (type == null) return new Type[0];
	    
			ArrayList result = new ArrayList(type.GetInterfaces());
	
			if (type.BaseType != null)
				foreach (Type interfaceType in type.BaseType.GetInterfaces())
					if (result.Contains(interfaceType))
						result.Remove(interfaceType);
	
			foreach (Type interfaceType in type.GetInterfaces())
				foreach (Type interfaceBase in interfaceType.GetInterfaces())
					if (result.Contains(interfaceBase))
						result.Remove(interfaceBase);
	
			return (Type[]) result.ToArray(typeof(Type));
		}
	
		public static Type[] GetBaseTypes(Type type)
		{
			ArrayList result = new ArrayList();
			if (type.BaseType != null) result.Add(type.BaseType);
			result.AddRange(GetInterfaces(type));
			return (Type[]) result.ToArray(typeof(Type));
		}
	
		public static String GetResolutionScope(Type type)
		{
			if (type.DeclaringType != null)
			{
				String resolutionScope = GetResolutionScope(type.DeclaringType);
				if (resolutionScope != String.Empty) resolutionScope += ".";
				return resolutionScope + type.DeclaringType.Name;
			}
	
			return (type.Namespace != null) ? type.Namespace : String.Empty;
		}
	
		public static String GetFullName(Type type)
		{
			if (type == null) return String.Empty;
			String resolutionScope = GetResolutionScope(type);
			if (resolutionScope != String.Empty) resolutionScope += ".";
			return resolutionScope + type.Name;
		}
	}
	
	class MethodHelper
	{
		static Type propertyType = null;
		static PropertyInfo[] propertyCache = null;
		static Type eventType = null;
		static EventInfo[] eventCache = null;
	
		public static Boolean IsPropertyMethod(MethodInfo methodInfo, PropertyInfo[] properties)
		{
			if (properties == null)
			{
				if (methodInfo.DeclaringType == null) return false;
				if (methodInfo.DeclaringType != propertyType)
				{
					propertyType = methodInfo.DeclaringType;
					propertyCache = new PropertyInfo[0];
					try { propertyCache = propertyType.GetProperties(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Instance); } 
					catch { }
				}
				properties = propertyCache;
			}
	
			foreach (PropertyInfo propertyInfo in properties)
				if ((propertyInfo.GetGetMethod(true) == methodInfo) || (propertyInfo.GetSetMethod(true) == methodInfo))
					return true;
	
			return false;
		}
	
		public static Boolean IsEventMethod(MethodInfo methodInfo, EventInfo[] events)
		{
			if (events == null)
			{
				if (methodInfo.DeclaringType == null) return false;
				if (methodInfo.DeclaringType != eventType) 
				{
					eventType = methodInfo.DeclaringType;
					eventCache = new EventInfo[0];
					try { eventCache = eventType.GetEvents(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Instance); } 
					catch { }
				}
				events = eventCache;
			}
	
			foreach (EventInfo eventInfo in events)
				if ((eventInfo.GetAddMethod(true) == methodInfo) || (eventInfo.GetRemoveMethod(true) == methodInfo) || (eventInfo.GetRaiseMethod(true) == methodInfo))
					return true;
	
			return false;
		}
	
		public static String GetParametersText(ParameterInfo[] parameters, Boolean varArgs)
		{
			String str = "(";
			foreach (ParameterInfo parameterInfo in parameters)
			{
				str += (parameterInfo.ParameterType != null) ? parameterInfo.ParameterType.Name : "?";
				if (parameterInfo != parameters[parameters.Length - 1])
					str += ", ";
				else
					if (varArgs) str += ", ...";
			}
			str += ")";
			return str;
		}
	}
	
	class FieldHelper
	{
		public static Boolean IsEnumerationElement(FieldInfo fieldInfo)
		{
			Type declaringType = fieldInfo.DeclaringType;
			return ((declaringType != null) && (declaringType.IsEnum) && (declaringType == fieldInfo.FieldType));	
		}
	}
	
	class TypeComparer : IComparer
	{
		public int Compare(Object x, Object y)
		{
			Type a = (Type) x;
			Type b = (Type) y;
			if (a.Namespace == b.Namespace) return a.Name.CompareTo(b.Name);
			if (a.Namespace == null) return +1;
			if (b.Namespace == null) return -1;
			return a.Namespace.CompareTo(b.Namespace);
		}
	}
	
	class MemberComparer : IComparer
	{
		public int Compare(Object x, Object y)
		{
			MemberInfo a = (MemberInfo) x;
			MemberInfo b = (MemberInfo) y;
			return MemberHelper.GetText(a).CompareTo(MemberHelper.GetText(b));
		}
	}
	
	class MemberHelper
	{
		public static String GetText(MemberInfo memberInfo)
		{
			String str = String.Empty;
	
			if (memberInfo is ConstructorInfo)
			{
				ConstructorInfo constructorInfo = (ConstructorInfo) memberInfo;
				str = constructorInfo.Name;
				str += MethodHelper.GetParametersText(constructorInfo.GetParameters(), constructorInfo.CallingConvention == CallingConventions.VarArgs);
			}
	
			if (memberInfo is MethodInfo)
			{
				MethodInfo methodInfo = (MethodInfo) memberInfo;
				str = methodInfo.Name;
				str += MethodHelper.GetParametersText( methodInfo.GetParameters(), methodInfo.CallingConvention == CallingConventions.VarArgs);
				String returnTypeName = (methodInfo.ReturnType != null) ? methodInfo.ReturnType.Name : "?";
				str += " : " + returnTypeName;
			}
	
			if (memberInfo is EventInfo)
			{
				EventInfo eventInfo = (EventInfo) memberInfo;
				str = eventInfo.Name;
			}
	
			if (memberInfo is PropertyInfo)
			{
				PropertyInfo propertyInfo = (PropertyInfo) memberInfo;
				str = propertyInfo.Name;
				ParameterInfo[] parameters = propertyInfo.GetIndexParameters();
				if (parameters.Length > 0) str += MethodHelper.GetParametersText(parameters, false);
				str += " : " + propertyInfo.PropertyType.Name;
			}
	
			if (memberInfo is FieldInfo)
			{
				FieldInfo fieldInfo = (FieldInfo) memberInfo;
				str = fieldInfo.Name;
				if (!FieldHelper.IsEnumerationElement(fieldInfo))
					str += " : " + fieldInfo.FieldType.Name;
			}
	
			return str;
		}
	}
}
